import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchComponent } from './search/search.component';
import { DisplayComponent } from './display/display.component';
import { HttpClient, HttpClientModule } from'@angular/common/http';
import { AddComponent } from './add/add.component';
import { SortingPipe } from './sorting.pipe';


@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    DisplayComponent,
    AddComponent,
    SortingPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
