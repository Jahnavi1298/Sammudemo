import { Component } from '@angular/core';
import { ProductService} from './product.service';
import { Router} from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SearchDemo';
  service: ProductService;
 router:Router;
 /**
 * injecting this component with service and router
 * 
 * @param service 
 * @param router 
 */
 constructor(service:ProductService,router:Router){
 this.service=service;
 this.router=router;
 }
 
 ngOnInit(){
 //
 //redirect to listing component at start
 //
 this.router.navigate(['app-display'])
 }
 
 
}
