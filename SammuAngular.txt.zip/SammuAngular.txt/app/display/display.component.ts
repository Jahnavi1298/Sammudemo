import { Component, OnInit } from '@angular/core';
import { ProductService, Product} from '../product.service';
@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  service:ProductService;
 
 constructor(service:ProductService) { 
 this.service=service;
 }
 product:Product[]=[];  

 delete(id:number){
  this.service.delete(id);
  this.product=this.service.getProducts();
  }
  isUpdate:boolean=true;
 updateData()
 {
 this.isUpdate=!this.isUpdate;
 }
 update(data:any)
 {
 this.service.update(data);
 this.product=this.service.getProducts();
 }
  column:string="id"; 
 order:boolean=true;
 sort(column:string){ 
 if(this.column==column )
 {
 this.order=!this.order;
 }
 else{
 this.order=true;
 this.column=column;
 }
 }


  ngOnInit() {
    this.product = this.service.getProducts();
  }
}
