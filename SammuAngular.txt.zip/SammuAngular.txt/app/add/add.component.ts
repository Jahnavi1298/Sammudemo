import { Component, OnInit } from '@angular/core';
import { Product,ProductService} from '../product.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  createdProduct:Product;
 
 createdFlag:boolean=false;
 
 service:ProductService;
 constructor(service:ProductService) { 
 this.service=service;
 }
 
 ngOnInit() {
 }
 add(data:any){
 this.createdProduct=new Product(data.pid,data.pname,data.pprice,data.pcategory);
 this.service.add(this.createdProduct);
 this.createdFlag=true;
 }
 
}