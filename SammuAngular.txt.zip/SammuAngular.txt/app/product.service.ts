import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  

 
http:HttpClient;
 
product:Product[]=[];
constructor(http:HttpClient){
this.http=http;
this.fetchProducts();
 }
fetched:boolean=false;

private fetchProducts(){
this.http.get('./assets/product.json').subscribe(
data=>{
if(!this.fetched){ 
this.convert(data);
this.fetched=true;
 }
 });

 }

getProducts():Product[]{
return this.product;
 }

convert(data:any){
for(let o of data["Product"]){
let p=new Product(o.id,o.name,o.price,o.category);
this.product.push(p);
 } 
}

add(p:Product){

this.product.push(p);
 }

 delete(pid:number){
 let foundIndex:number=-1;
 for(let i=0;i<this.product.length;i++){
 let p=this.product[i];
 if(pid==p.id){
 foundIndex=i ;
 break;
  }
  }
 
 this.product.splice(foundIndex,1); 
  }

  update(data: Product)
   {
  
    let pid = data.id;
  
  for(let i=0;i<this.product.length;i++)
   {
  
    if(pid == this.product[i].id)
   {
  this.product[i].id=data.id;
  this.product[i].name=data.name;
  this.product[i].price=data.price;
  this.product[i].category=data.category;
  break;
   }
   }
   }
  }
  
  
 
 


 
 export class Product{
  static COLUMNS=['id','name','price','category'];
  id:number;
  name:string;
  price:number;
  category:string;
  constructor(id:number,name:string, price:number,category:string){
  this.id=id;
  this.name=name;
  this.price=price;
  this.category=category;
  }

}

